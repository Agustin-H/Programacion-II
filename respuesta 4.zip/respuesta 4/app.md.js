
class profecion {
  constructor(nombre,horas,precio) {
      this.nombre = nombre;
      this.horas = horas;
      this.precio = precio;
  }
  calcularAguinaldo(horas,precio)
  {
      let total;
      total = this.horas * this.precio;
     return total;
  }
}
class abogado extends profecion{
    constructor(nombre,horas,precio)
    {
      super(nombre,horas,precio);
      this.nombre= nombre;
      this.horas = horas;
      this.precio = precio;
    }
}
class secretario extends profecion{
    constructor(nombre,horas,precio)
    {
      super(nombre,horas,precio);
      this.nombre=nombre;
      this.horas = horas;
      this.precio = precio;
    }
}
let abogad = new abogado("Pedro",10,10);
let secret = new secretario("Sofia",10,5);
console.log("Aguinalde del Secretario: ",secret.calcularAguinaldo() + "nombre: " + secret.nombre);
console.log("Aguinaldo del abogado: ",abogad.calcularAguinaldo() + "nombre: " + abogad.nombre);
